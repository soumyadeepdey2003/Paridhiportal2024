package soumya.megatronix.portal2023.PortalRestAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortalRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
