package soumya.megatronix.portal2023.PortalRestAPI.Configuration;

public class AppConstants {
    public static final long JWT_TOKEN_VALIDITY = 15 * 24 * 60 * 60;
}
