package soumya.megatronix.portal2023.PortalRestAPI.Portal.User.RD.Repository.robotics;

import org.springframework.data.jpa.repository.JpaRepository;
import soumya.megatronix.portal2023.PortalRestAPI.Portal.User.RD.Model.robotics.RoboticsWarComboModel;

public interface RoboticsWarComboRepository extends JpaRepository<RoboticsWarComboModel, Long> {
}
