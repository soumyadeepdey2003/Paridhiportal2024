package soumya.megatronix.portal2023.PortalRestAPI.Portal.Admin.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
import soumya.megatronix.portal2023.PortalRestAPI.Configuration.AppConstants;

import javax.crypto.SecretKey;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class JwtService {

//    static Dotenv dotenv = Dotenv.load();
    //  get the secret key from the environment variable

    //  extract the username from the token
    public String extractUsername ( String token ) {
        return extractClaim(token, Claims::getSubject);
    }

    //  generate the token
    public String generateToken ( UserDetails userDetails ) {
        return generateToken(new HashMap<>(), userDetails);
    }

    //  generate the token with extra claims
    public String generateToken (
            Map<String, Object> extraClaims,
            UserDetails userDetails
    ) {
        Collection<? extends GrantedAuthority> authorities = userDetails.getAuthorities();
        List<String> roles = authorities.stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.toList());
        extraClaims.put("roles", roles);

        return Jwts.builder()
                .claims(extraClaims)
                .subject(userDetails.getUsername())
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + AppConstants.JWT_TOKEN_VALIDITY))
                .signWith(getSecretKey())
                .compact();
    }

    //  validate the token
    public boolean validateToken ( String token, UserDetails userDetails ) {
        final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }

    //  check if the token is expired
    private boolean isTokenExpired ( String token ) {
        return extractExpiration(token).before(new Date());
    }

    //  extract the expiration date from the token
    private Date extractExpiration ( String token ) {
        return extractClaim(token, Claims::getExpiration);
    }

    // extract the claim from the token
    public <T> T extractClaim ( String token, Function<Claims, T> claimsResolver) {
        final Claims claim = extractAllClaims(token);
        return claimsResolver.apply(claim);
    }

    //  extract all claims from the token
    private Claims extractAllClaims ( String token ) {
        return Jwts.parser()
                .verifyWith(getSecretKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    //  get the secret key
    private SecretKey getSecretKey () {
        String SECRET_KEY = "5c9d8e5e678a8d2f2b01ab2c2c5f0e798d8e5e234678a8d2f2b01ab2c2c5f0e798d8e5e234678a8d2f2b01ab2c2c5f0e798d8e5e234678a8d2f2b01ab2c2c5f0e798d8e5e234678a8d2f2b01ab2c2c5f0e798d8e5e234678a8d2f2b01ab2c2c5f0e798";
        byte[] keyBytes = Decoders.BASE64.decode(SECRET_KEY);
        return Keys.hmacShaKeyFor(keyBytes);
    }

}
